<?php

function DocumentFooter()
{
    $html = "
    <footer class='footer'>
        <div class='footer-left'>
            <p>© Rehabilitación Integral Laboral y Ocupacional. RILO SAS " . date('Y') . "</p>
            <p><i class='bi bi-geo-alt-fill'></i><span>Neiva-Huila, Carrera 8b #12-24 Barrio Chapinero</span></p>
            <p>
                <i class='bi bi-telephone-fill'></i>
                <span>Tel: 
                    <a href='tel:573182675427'>+57 3182675427</a> - 
                    <a href='tel:576018721481'>(+57) 601 8721481</a>
                </span>
            </p>
        </div>
        <div class='footer-right'>
            <p><i class='bi bi-person'></i><a href='../estados/'>Estados financieros</a></p>
        </div>
    </footer>
    ";
    return $html;
}
