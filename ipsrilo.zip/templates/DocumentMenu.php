<?php
function DocumentMenu($active)
{
    $inicio = "";
    $servicios = "";
    $acerca = "";
    if ($active == "inicio") {
        $inicio = "active";
    } else if ($active == "servicios") {
        $servicios = "active";
    } else if ($active == "acerca") {
        $acerca = "active";
    } else {
        $inicio = "";
        $servicios = "";
        $acerca = "";
    }
    $html = "
    <div class='container-menu'>
        <div class='container-logo'>
            <img src='../../static/img/logo.webp' alt='Logo Rido' />
        </div>
        <nav class='nav'>
            <a href='../inicio/' class='nav-link $inicio'>Inicio</a>
            <a href='../acerca/' class='nav-link $acerca'>Acerca de</a>
            <a href='../servicios/' class='nav-link $servicios'>Servicios</a>
        </nav>
    </div>
    ";
    return $html;
}
