<?php
function DocumentHeader()
{
    $html = "
    <header class='header'>
        <div class='section-blue'>
        </div>
        <div class='container-links-header'>
            <div class='flex-left'>
                <div class='container-icon'>
                    <i class='bi bi-geo-alt-fill'></i>
                </div>
                <div class='container-p'>
                    <p>Neiva-Huila, Carrera 8b #12-24 Barrio Chapinero</p>
                    <p>Lunes-Viernes 8 am-12, 2 pm- 6 pm, Sabados 8 am.12</p>
                </div>
            </div>
            <div class='flex-right'>
                <div class='container-icon'>
                    <i class='bi bi-telephone-fill'></i>
                </div>
                <div class='container-p'>
                    <p><a href='tel:573182675427'>Tel: (+57) 3182675427</a></p><span>-</span>
                    <p><a href='tel:576018721481'>(+57) 601 8721481</a></p>
                </div>
            </div>
        </div>
    </header>
    ";
    return $html;
}
