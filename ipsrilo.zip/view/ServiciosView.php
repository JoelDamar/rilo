<?php
echo DocumentHeader();
echo "<main class='main'>";
echo DocumentMenu('servicios');
echo "</main>";
echo DocumentFooter();
?>
</body>

</html>