<?php
echo DocumentHeader();
echo "<main class='main'>";
echo DocumentMenu('inicio');
?>
<div class="container">
    <div class="slider">
        <div class="arrow-left">
            <button class="btn-arrow btn-arrow-left"><i class="bi bi-chevron-left"></i></button>
        </div>
        <?php
        for ($i = 1; $i <= 5; $i++) {
            echo '<div class="slider-item">
                    <img src="../../static/img/slider/img' . $i . '.jpg" alt="img slider">
                 </div>';
        }
        ?>
        <div class="arrow-right">
            <button class="btn-arrow btn-arrow-right"><i class="bi bi-chevron-right"></i></button>
        </div>
    </div>
</div>


<?php
echo "</main>";
echo DocumentFooter();
?>
</body>

</html>