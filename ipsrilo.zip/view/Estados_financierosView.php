<?php
echo DocumentHeader();
echo "<main class='main'>";
echo DocumentMenu('estado');
echo "</main>";
echo DocumentFooter();
?>
</body>

</html>