<?php
require_once '../../utils/ArletLoad.php';
$DocumentHtml = new DocumentHtml('Servicios');
echo $DocumentHtml->getDocumentHtml();
