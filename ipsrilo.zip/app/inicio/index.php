<?php
require_once '../../utils/ArletLoad.php';
$DocumentHtml = new DocumentHtml('Inicio');
echo $DocumentHtml->getDocumentHtml();
