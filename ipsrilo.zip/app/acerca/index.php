<?php
require_once '../../utils/ArletLoad.php';
$DocumentHtml = new DocumentHtml('acerca_de');
echo $DocumentHtml->getDocumentHtml();
