<?php
require_once '../../utils/ArletLoad.php';
$DocumentHtml = new DocumentHtml('Estados_financieros');
echo $DocumentHtml->getDocumentHtml();
