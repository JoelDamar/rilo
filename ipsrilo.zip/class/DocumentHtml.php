<?php
class DocumentHtml
{
    public $title;
    public $css;
    public $path;
    public $vista;

    public function __construct($title)
    {
        $this->title = $title;
        $this->css = mb_strtolower($title, 'UTF-8');
        $this->path = '../../';
        $this->vista = '../../view/' . ucfirst($title) . 'View.php';
    }
    public  function getDocumentHtml()
    {
        $html = "
            <!DOCTYPE html>
            <html lang='es'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1'>
                <meta http-equiv='X-UA-Compatible' content='ie=edge'>
                <title>Rilo | " . ucfirst(str_replace("_", " ", $this->title)) . "</title>
                <link rel='shortcut icon' href='$this->path" . "static/img/favicon.png' type='image/x-icon'>
                <link rel='stylesheet' href='$this->path" . "node_modules/bootstrap-icons/font/bootstrap-icons.css'>
                <link rel='stylesheet' href='$this->path" . "node_modules/normalize.css/normalize.css'>
                <link rel='stylesheet' href='$this->path" . "static/css/$this->css.css?version=" . time() . "'>
                <script src='$this->path" . "node_modules/jquery/dist/jquery.min.js'></script>
            </head>
            <body>
            ";
        ob_start();
        include $this->vista;
        $html .= ob_get_clean();
        $html .= "
                 <script src='$this->path" . "static/js/const.js?version=" . time() . "'></script>
                 <script src='$this->path" . "static/js/functions/const.js?version=" . time() . "'></script>
                 <script src='$this->path" . "static/js/$this->css.js?version=" . time() . "'></script>
                 <script src='$this->path" . "static/js/functions/$this->css.js?version=" . time() . "'></script>

                </body>
                </html>
                ";

        return $html;
    }
}
