<?php
date_default_timezone_set('America/Bogota');
class ArletLoad
{
    public function __construct()
    {
        spl_autoload_register(function ($class) {
            $ruta = "../../class/$class.php";
            if (file_exists($ruta)) {
                require_once $ruta;
            } else {
                echo "El archivo no existe";
            }
        });
    }

    public function getOtherFiles($path)
    {
        $files = scandir($path);
        $files = array_diff($files, ['.', '..']);
        foreach ($files as $file) {
            $ruta = "$path/$file";
            if (is_dir($ruta)) {
                $this->getOtherFiles($ruta);
            } else {
                require_once $ruta;
            }
        }
    }
}

$ArletLoad = new ArletLoad();
$ArletLoad->getOtherFiles('../../templates');
